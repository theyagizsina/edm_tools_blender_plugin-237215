import math

blender_lamp_energy_coefficient = 0.0000305
blender_lamp_weak_coefficient = 1.0/2.9